const repository = require('./repository/type');
const author = require('./author/type');

module.exports = [
  repository,
  author,
];
